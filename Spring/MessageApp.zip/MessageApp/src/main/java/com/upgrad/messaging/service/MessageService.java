package com.upgrad.messaging.service;

public interface MessageService {

    public void send(String msg);
}
