package com.upgrad.spring;

public class GreetingService {
    
    public void greet(String name){
        System.out.println("Hello " + name);
    }
}
