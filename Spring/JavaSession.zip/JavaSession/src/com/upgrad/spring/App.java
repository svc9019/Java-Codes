package com.upgrad.spring;

public class App {

    public static void main(String[] args) {
        GreetingService greetingService = new GreetingService();
        greetingService.greet("Vishwa");
    }
}
