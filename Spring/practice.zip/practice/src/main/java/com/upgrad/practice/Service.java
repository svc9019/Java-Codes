package com.upgrad.practice;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Profile("dev ")
public class Service {
    @RequestMapping(value = "/page3")
    public String page3(){
        return "Hello World";
    }
}
