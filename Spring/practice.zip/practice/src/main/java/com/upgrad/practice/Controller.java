package com.upgrad.practice;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @RequestMapping(value = "/page1")
    public String pageOne(){
        return "This is the first task of this exercise";
    }
    @RequestMapping(value = "/page2")
    public String pageTwo(){
        return "This is the second task of this exercise";
    }
}
