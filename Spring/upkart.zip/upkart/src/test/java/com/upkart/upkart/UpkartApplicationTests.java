package com.upkart.upkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
