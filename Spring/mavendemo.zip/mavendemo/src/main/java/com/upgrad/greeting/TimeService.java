package com.upgrad.greeting;

public interface TimeService {

    public int getCurrentTime();
}
