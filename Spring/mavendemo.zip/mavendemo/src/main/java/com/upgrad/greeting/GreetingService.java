package com.upgrad.greeting;

public interface GreetingService {

    public void greet(String name);
}
