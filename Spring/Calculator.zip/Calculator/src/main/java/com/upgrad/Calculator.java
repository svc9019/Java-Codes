package com.upgrad;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Calculator {

    private MathService additionService;
    private MathService subtractionService;
    private MathService multiplicationService;
    private MathService divisionService;

    @Autowired
    public  Calculator(@Qualifier("additionService") MathService additionService,
                       @Qualifier("subtractionService") MathService subtractionService,
                       @Qualifier("multiplicationService") MathService multiplicationService,
                       @Qualifier("divisionService") MathService divisionService){
        this.additionService = additionService;
        this.subtractionService = subtractionService;
        this.divisionService = divisionService;
        this.multiplicationService = multiplicationService;
    }

    public void compute(String op, int x, int y){
        if(op.equals("add")){
            additionService.operate(x,y);
        }else if(op.equals("subtract")){
            subtractionService.operate(x,y);
        }else if(op.equals("multiply")){
            multiplicationService.operate(x,y);
        }else if (op.equals("divide")){
            divisionService.operate(x,y);
        } else{
            throw new RuntimeException(op + " is not supported by this calculator");
        }
    }


}
