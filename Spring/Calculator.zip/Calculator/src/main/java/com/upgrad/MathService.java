package com.upgrad;

public interface MathService {
    public void operate(int x, int y);
}
