package com.upgrad.spring;

public interface GreetingService {
    
    public void greet(String name);
}
